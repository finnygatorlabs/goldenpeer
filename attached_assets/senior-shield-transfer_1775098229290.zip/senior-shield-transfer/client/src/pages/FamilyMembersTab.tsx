import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Users, Plus, Edit2, Trash2, Mail, AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";

/**
 * Family Members Tab - Manage family members who receive email notifications
 */
export default function FamilyMembersTab() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    relationship: "",
    notificationPreference: "all" as const,
  });

  // Queries and mutations
  const { data: familyMembers = [], isLoading, refetch } = trpc.familyMembers.list.useQuery();
  const addMutation = trpc.familyMembers.add.useMutation();
  const updateMutation = trpc.familyMembers.update.useMutation();
  const deleteMutation = trpc.familyMembers.delete.useMutation();

  const handleAdd = async () => {
    if (!formData.name || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await addMutation.mutateAsync(formData);
      toast.success("Family member added successfully");
      setFormData({ name: "", email: "", relationship: "", notificationPreference: "all" });
      setIsAddDialogOpen(false);
      refetch();
    } catch (error) {
      toast.error("Failed to add family member");
      console.error(error);
    }
  };

  const handleUpdate = async (id: number) => {
    if (!formData.name || !formData.email) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await updateMutation.mutateAsync({
        id,
        ...formData,
      });
      toast.success("Family member updated successfully");
      setFormData({ name: "", email: "", relationship: "", notificationPreference: "all" });
      setEditingId(null);
      refetch();
    } catch (error) {
      toast.error("Failed to update family member");
      console.error(error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to remove this family member?")) return;

    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Family member removed");
      refetch();
    } catch (error) {
      toast.error("Failed to remove family member");
      console.error(error);
    }
  };

  const startEdit = (member: any) => {
    setFormData({
      name: member.name,
      email: member.email,
      relationship: member.relationship || "",
      notificationPreference: member.notificationPreference,
    });
    setEditingId(member.id);
  };

  const cancelEdit = () => {
    setFormData({ name: "", email: "", relationship: "", notificationPreference: "all" });
    setEditingId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="w-6 h-6 text-blue-600" />
          <div>
            <h2 className="text-2xl font-bold text-foreground">Family Members</h2>
            <p className="text-sm text-muted-foreground">Manage who receives email notifications</p>
          </div>
        </div>

        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="w-4 h-4" />
              Add Family Member
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Family Member</DialogTitle>
              <DialogDescription>
                Add a family member who will receive email notifications about reminders
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground">Name *</label>
                <Input
                  placeholder="e.g., John Smith"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Email *</label>
                <Input
                  type="email"
                  placeholder="john@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Relationship</label>
                <Input
                  placeholder="e.g., Son, Daughter, Spouse"
                  value={formData.relationship}
                  onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground">Notification Preference</label>
                <Select
                  value={formData.notificationPreference}
                  onValueChange={(value: any) =>
                    setFormData({ ...formData, notificationPreference: value })
                  }
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All reminders</SelectItem>
                    <SelectItem value="missed_only">Missed reminders only</SelectItem>
                    <SelectItem value="summary_only">Daily summary only</SelectItem>
                    <SelectItem value="none">No notifications</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleAdd}
                disabled={addMutation.isPending}
                className="w-full"
              >
                {addMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Adding...
                  </>
                ) : (
                  "Add Family Member"
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Info Alert */}
      <Alert>
        <Mail className="h-4 w-4" />
        <AlertDescription>
          Family members will receive email notifications based on their preference settings. They can be notified about all reminders, only missed reminders, or just daily summaries.
        </AlertDescription>
      </Alert>

      {/* Family Members List */}
      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : familyMembers.length === 0 ? (
        <Card className="p-12 text-center">
          <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
          <h3 className="font-semibold text-foreground mb-2">No family members yet</h3>
          <p className="text-sm text-muted-foreground mb-6">
            Add family members to receive email notifications about your reminders
          </p>
          <Button onClick={() => setIsAddDialogOpen(true)} variant="outline">
            Add Your First Family Member
          </Button>
        </Card>
      ) : (
        <div className="grid gap-4">
          {familyMembers.map((member: any) => (
            <Card key={member.id} className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-foreground">{member.name}</h3>
                    {member.relationship && (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                        {member.relationship}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                    <Mail className="w-4 h-4" />
                    {member.email}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Notifications: <span className="font-medium capitalize">{member.notificationPreference.replace(/_/g, " ")}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Dialog open={editingId === member.id} onOpenChange={(open) => !open && cancelEdit()}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => startEdit(member)}
                        className="gap-1"
                      >
                        <Edit2 className="w-4 h-4" />
                        <span className="hidden sm:inline">Edit</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Family Member</DialogTitle>
                      </DialogHeader>

                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium text-foreground">Name</label>
                          <Input
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <label className="text-sm font-medium text-foreground">Email</label>
                          <Input
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <label className="text-sm font-medium text-foreground">Relationship</label>
                          <Input
                            value={formData.relationship}
                            onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
                            className="mt-1"
                          />
                        </div>

                        <div>
                          <label className="text-sm font-medium text-foreground">Notification Preference</label>
                          <Select
                            value={formData.notificationPreference}
                            onValueChange={(value: any) =>
                              setFormData({ ...formData, notificationPreference: value })
                            }
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All reminders</SelectItem>
                              <SelectItem value="missed_only">Missed reminders only</SelectItem>
                              <SelectItem value="summary_only">Daily summary only</SelectItem>
                              <SelectItem value="none">No notifications</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleUpdate(member.id)}
                            disabled={updateMutation.isPending}
                            className="flex-1"
                          >
                            {updateMutation.isPending ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              "Save Changes"
                            )}
                          </Button>
                          <Button variant="outline" onClick={cancelEdit}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(member.id)}
                    disabled={deleteMutation.isPending}
                    className="gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span className="hidden sm:inline">Remove</span>
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
