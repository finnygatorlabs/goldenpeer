import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Bell, Pill, Droplets, Apple, Clock, Trash2, Plus, CheckCircle2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

type ReminderType = "medication" | "water" | "meal" | "appointment" | "wellness" | "custom";

const reminderTypeIcons: Record<ReminderType, React.ReactNode> = {
  medication: <Pill className="w-5 h-5" />,
  water: <Droplets className="w-5 h-5" />,
  meal: <Apple className="w-5 h-5" />,
  appointment: <Clock className="w-5 h-5" />,
  wellness: <CheckCircle2 className="w-5 h-5" />,
  custom: <Bell className="w-5 h-5" />,
};

const reminderTypeLabels: Record<ReminderType, string> = {
  medication: "Medication",
  water: "Water",
  meal: "Meal",
  appointment: "Appointment",
  wellness: "Wellness Check",
  custom: "Custom",
};

export default function RemindersTab() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    type: "medication" as ReminderType,
    title: "",
    description: "",
    time: "09:00",
    frequency: "daily",
    dosage: "",
  });

  const remindersQuery = trpc.reminders.list.useQuery();
  const createMutation = trpc.reminders.create.useMutation();
  const updateMutation = trpc.reminders.update.useMutation();
  const deleteMutation = trpc.reminders.delete.useMutation();
  const testNotificationMutation = trpc.reminders.testNotification.useMutation();

  const handleOpenDialog = (reminder?: any) => {
    if (reminder) {
      setEditingId(reminder.id);
      setFormData({
        type: reminder.type,
        title: reminder.title,
        description: reminder.description || "",
        time: reminder.time,
        frequency: reminder.frequency,
        dosage: reminder.dosage || "",
      });
    } else {
      setEditingId(null);
      setFormData({
        type: "medication",
        title: "",
        description: "",
        time: "09:00",
        frequency: "daily",
        dosage: "",
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title.trim()) {
      toast.error("Please enter a reminder title");
      return;
    }

    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          ...formData,
        });
        toast.success("Reminder updated");
      } else {
        await createMutation.mutateAsync(formData);
        toast.success("Reminder created");
      }
      setIsDialogOpen(false);
      remindersQuery.refetch();
    } catch (error) {
      toast.error("Failed to save reminder");
      console.error(error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this reminder?")) return;

    try {
      await deleteMutation.mutateAsync({ id });
      toast.success("Reminder deleted");
      remindersQuery.refetch();
    } catch (error) {
      toast.error("Failed to delete reminder");
      console.error(error);
    }
  };

  const handleTestNotification = async (id: number) => {
    try {
      await testNotificationMutation.mutateAsync({ reminderId: id });
      toast.success("Test notification sent!");
    } catch (error) {
      toast.error("Failed to send test notification");
      console.error(error);
    }
  };

  const reminders = remindersQuery.data || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Daily Reminders</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Choose up to 3 reminders. Your AI assistant will check in with you each day.
          </p>
        </div>
        <Button onClick={() => handleOpenDialog()} className="gap-2">
          <Plus className="w-4 h-4" />
          Add Reminder
        </Button>
      </div>

      {/* Active Reminders Count */}
      {reminders.length > 0 && (
        <Card className="bg-blue-50 border-blue-200 p-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">
              {reminders.length} of 3 active reminders
            </span>
          </div>
        </Card>
      )}

      {/* Reminders List */}
      {reminders.length === 0 ? (
        <Card className="p-8 text-center">
          <Bell className="w-12 h-12 mx-auto text-muted-foreground mb-4 opacity-50" />
          <p className="text-muted-foreground mb-4">No reminders yet</p>
          <Button onClick={() => handleOpenDialog()} variant="outline">
            Create your first reminder
          </Button>
        </Card>
      ) : (
        <div className="space-y-3">
          {reminders.map(reminder => (
            <Card key={reminder.id} className="p-4">
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className="text-blue-600 mt-1">
                  {reminderTypeIcons[reminder.type as ReminderType]}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">{reminder.title}</h3>
                      {reminder.description && (
                        <p className="text-sm text-muted-foreground mt-1">{reminder.description}</p>
                      )}
                      {reminder.dosage && (
                        <p className="text-sm text-muted-foreground mt-1">Dosage: {reminder.dosage}</p>
                      )}
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {reminder.time}
                        </span>
                        <span className="capitalize">{reminder.frequency}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleTestNotification(reminder.id)}
                        disabled={testNotificationMutation.isPending}
                      >
                        Test
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleOpenDialog(reminder)}
                      >
                        Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(reminder.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Info Box */}
      <Card className="bg-amber-50 border-amber-200 p-4">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-900">
            <p className="font-medium mb-1">Push Notifications Required</p>
            <p>
              To receive reminders, make sure push notifications are enabled in your device settings. You'll get a notification at the scheduled time, even if you're not in the app.
            </p>
          </div>
        </div>
      </Card>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Reminder" : "Add New Reminder"}</DialogTitle>
            <DialogDescription>
              Set up a reminder to help you stay on track with your daily routine.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Type */}
            <div>
              <Label htmlFor="type">Reminder Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value as ReminderType })}>
                <SelectTrigger id="type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(reminderTypeLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Title */}
            <div>
              <Label htmlFor="title">What should I remind you about?</Label>
              <Input
                id="title"
                placeholder="e.g., Take blood pressure medication"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            {/* Description */}
            <div>
              <Label htmlFor="description">Additional Details (Optional)</Label>
              <Textarea
                id="description"
                placeholder="e.g., Take with food and water"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={2}
              />
            </div>

            {/* Time */}
            <div>
              <Label htmlFor="time">Time</Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              />
            </div>

            {/* Frequency */}
            <div>
              <Label htmlFor="frequency">Frequency</Label>
              <Select value={formData.frequency} onValueChange={(value) => setFormData({ ...formData, frequency: value })}>
                <SelectTrigger id="frequency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Every Day</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Dosage (for medication) */}
            {formData.type === "medication" && (
              <div>
                <Label htmlFor="dosage">Dosage (Optional)</Label>
                <Input
                  id="dosage"
                  placeholder="e.g., 2 tablets, 5ml"
                  value={formData.dosage}
                  onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                />
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending} className="flex-1">
                {editingId ? "Update" : "Create"} Reminder
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
