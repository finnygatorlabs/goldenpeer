import { useEffect } from 'react';
import { usePushNotifications } from '@/_core/hooks/usePushNotifications';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Bell, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

interface NotificationSetupProps {
  onComplete?: () => void;
  showSkip?: boolean;
}

/**
 * Component to set up push notifications
 * Can be used in onboarding or settings
 */
export function NotificationSetup({ onComplete, showSkip = true }: NotificationSetupProps) {
  const { isSupported, isPermissionGranted, isLoading, error, requestPermission } = usePushNotifications();

  // Auto-complete if permission is already granted
  useEffect(() => {
    if (isPermissionGranted && onComplete) {
      const timer = setTimeout(onComplete, 1000);
      return () => clearTimeout(timer);
    }
  }, [isPermissionGranted, onComplete]);

  if (!isSupported) {
    return (
      <Card className="p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Push notifications are not supported on this device. Some reminder features may not work.
          </AlertDescription>
        </Alert>
      </Card>
    );
  }

  if (isPermissionGranted) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-4">
          <CheckCircle2 className="h-8 w-8 text-green-600" />
          <div>
            <h3 className="font-semibold text-foreground">Notifications Enabled</h3>
            <p className="text-sm text-muted-foreground">
              You'll receive reminders even when the app is closed.
            </p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start gap-3">
          <Bell className="h-6 w-6 text-blue-600 mt-1 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-foreground">Enable Notifications</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Get reminders for your medications, meals, and hydration even when you're not using the app.
            </p>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Benefits */}
        <div className="bg-blue-50 rounded-lg p-4 space-y-2">
          <p className="text-sm font-medium text-blue-900">Benefits:</p>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>✓ Reminders at the right time</li>
            <li>✓ Works even when app is closed</li>
            <li>✓ Family can see your adherence</li>
          </ul>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            onClick={requestPermission}
            disabled={isLoading}
            className="flex-1"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Setting up...
              </>
            ) : (
              <>
                <Bell className="w-4 h-4 mr-2" />
                Enable Notifications
              </>
            )}
          </Button>
          {showSkip && (
            <Button
              variant="outline"
              onClick={onComplete}
              disabled={isLoading}
            >
              Skip for now
            </Button>
          )}
        </div>

        {/* Info */}
        <p className="text-xs text-muted-foreground">
          You can change this anytime in Settings. We'll never spam you.
        </p>
      </div>
    </Card>
  );
}
