import { initializeApp } from 'firebase/app';
import { getMessaging, getToken, onMessage, Messaging } from 'firebase/messaging';

// Firebase configuration - these values should match your Firebase project
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVk",
  authDomain: "seniorshield-1eca9.firebaseapp.com",
  projectId: "seniorshield-1eca9",
  storageBucket: "seniorshield-1eca9.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:123456789:web:abcdef123456"
};

let messaging: Messaging | null = null;

/**
 * Initialize Firebase
 */
export function initializeFirebase() {
  try {
    const app = initializeApp(firebaseConfig);
    
    // Initialize Firebase Cloud Messaging
    if ('serviceWorker' in navigator) {
      messaging = getMessaging(app);
      console.log('[Firebase] Messaging initialized successfully');
    }
    
    return app;
  } catch (error) {
    console.error('[Firebase] Initialization failed:', error);
    throw error;
  }
}

/**
 * Register service worker for push notifications
 */
export async function registerServiceWorker() {
  try {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
      console.log('[Firebase] Service Worker registered:', registration);
      return registration;
    }
  } catch (error) {
    console.error('[Firebase] Service Worker registration failed:', error);
    throw error;
  }
}

/**
 * Request notification permission and get device token
 */
export async function requestNotificationPermission(): Promise<string | null> {
  try {
    if (!messaging) {
      console.error('[Firebase] Messaging not initialized');
      return null;
    }

    // Check if notifications are supported
    if (!('Notification' in window)) {
      console.warn('[Firebase] Notifications not supported in this browser');
      return null;
    }

    // Check current permission
    if (Notification.permission === 'granted') {
      console.log('[Firebase] Notification permission already granted');
      return await getDeviceToken();
    }

    if (Notification.permission === 'denied') {
      console.warn('[Firebase] Notification permission denied by user');
      return null;
    }

    // Request permission
    const permission = await Notification.requestPermission();
    
    if (permission === 'granted') {
      console.log('[Firebase] Notification permission granted');
      return await getDeviceToken();
    } else {
      console.warn('[Firebase] Notification permission denied');
      return null;
    }
  } catch (error) {
    console.error('[Firebase] Failed to request notification permission:', error);
    return null;
  }
}

/**
 * Get device token for push notifications
 */
export async function getDeviceToken(): Promise<string | null> {
  try {
    if (!messaging) {
      console.error('[Firebase] Messaging not initialized');
      return null;
    }

    // Get registration
    const registration = await navigator.serviceWorker.ready;

    // Get token
    const token = await getToken(messaging, {
      serviceWorkerRegistration: registration,
      vapidKey: import.meta.env.VITE_FIREBASE_VAPID_KEY || "BKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVkKzVk"
    });

    console.log('[Firebase] Device token obtained:', token);
    return token;
  } catch (error) {
    console.error('[Firebase] Failed to get device token:', error);
    return null;
  }
}

/**
 * Set up listener for foreground messages
 */
export function setupForegroundMessageListener(callback: (payload: any) => void) {
  try {
    if (!messaging) {
      console.error('[Firebase] Messaging not initialized');
      return;
    }

    onMessage(messaging, (payload) => {
      console.log('[Firebase] Foreground message received:', payload);
      callback(payload);
    });
  } catch (error) {
    console.error('[Firebase] Failed to set up foreground message listener:', error);
  }
}

/**
 * Check if push notifications are supported
 */
export function isPushNotificationSupported(): boolean {
  return 'serviceWorker' in navigator && 'Notification' in window;
}

/**
 * Get current notification permission status
 */
export function getNotificationPermissionStatus(): NotificationPermission {
  if ('Notification' in window) {
    return Notification.permission;
  }
  return 'denied';
}
