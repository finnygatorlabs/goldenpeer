import { useEffect, useState, useCallback } from 'react';
import { trpc } from '@/lib/trpc';
import {
  initializeFirebase,
  registerServiceWorker,
  requestNotificationPermission,
  setupForegroundMessageListener,
  isPushNotificationSupported,
  getNotificationPermissionStatus,
} from '@/lib/firebase';

interface UsePushNotificationsReturn {
  isSupported: boolean;
  isPermissionGranted: boolean;
  isLoading: boolean;
  error: string | null;
  requestPermission: () => Promise<void>;
  unregisterDevice: (token: string) => Promise<void>;
}

/**
 * Hook to manage push notifications setup
 */
export function usePushNotifications(): UsePushNotificationsReturn {
  const [isSupported] = useState(() => isPushNotificationSupported());
  const [isPermissionGranted, setIsPermissionGranted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const registerDeviceMutation = trpc.reminders.registerDevice.useMutation();
  const unregisterDeviceMutation = trpc.reminders.unregisterDevice.useMutation();

  // Initialize Firebase on mount
  useEffect(() => {
    if (!isSupported) {
      setError('Push notifications are not supported on this device');
      return;
    }

    const initialize = async () => {
      try {
        // Initialize Firebase
        initializeFirebase();

        // Register service worker
        await registerServiceWorker();

        // Check current permission status
        const permissionStatus = getNotificationPermissionStatus();
        setIsPermissionGranted(permissionStatus === 'granted');

        // Set up listener for foreground messages
        setupForegroundMessageListener((payload) => {
          console.log('[Notifications] Foreground message:', payload);
          
          // Show a notification even in foreground
          if ('Notification' in window && Notification.permission === 'granted') {
            const title = payload.notification?.title || 'SeniorShield Reminder';
            const options = {
              body: payload.notification?.body || 'You have a new reminder',
              icon: '/favicon.ico',
              badge: '/favicon.ico',
            };
            new Notification(title, options);
          }
        });
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to initialize notifications';
        setError(errorMessage);
        console.error('[Notifications] Initialization error:', err);
      }
    };

    initialize();
  }, [isSupported]);

  const requestPermission = useCallback(async () => {
    if (!isSupported) {
      setError('Push notifications are not supported on this device');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Request notification permission and get device token
      const token = await requestNotificationPermission();

      if (token) {
        // Register device token with backend
        await registerDeviceMutation.mutateAsync({
          token,
          deviceName: `${navigator.userAgent.substring(0, 50)}...`,
          platform: 'web',
        });

        setIsPermissionGranted(true);
        console.log('[Notifications] Device registered successfully');
      } else {
        setError('Failed to get device token');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to request permission';
      setError(errorMessage);
      console.error('[Notifications] Permission request error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [isSupported, registerDeviceMutation]);

  const unregisterDevice = useCallback(async (token: string) => {
    try {
      await unregisterDeviceMutation.mutateAsync({ token });
      setIsPermissionGranted(false);
      console.log('[Notifications] Device unregistered successfully');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to unregister device';
      setError(errorMessage);
      console.error('[Notifications] Unregister error:', err);
    }
  }, [unregisterDeviceMutation]);

  return {
    isSupported,
    isPermissionGranted,
    isLoading,
    error,
    requestPermission,
    unregisterDevice,
  };
}
