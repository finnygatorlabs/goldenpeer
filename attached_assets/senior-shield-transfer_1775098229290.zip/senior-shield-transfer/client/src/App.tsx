import { useEffect } from "react";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import SeniorShieldLanding from "./pages/SeniorShieldLanding";
import SplashScreenHeroVersion from "./pages/SplashScreenHeroVersion";
import Dashboard from "./pages/Dashboard";
import { initializeFirebase } from "@/lib/firebase";
import { Toaster } from "sonner";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/seniorshield"} component={SeniorShieldLanding} />
      <Route path={"/splash-hero"} component={SplashScreenHeroVersion} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  // Initialize Firebase on app mount
  useEffect(() => {
    try {
      initializeFirebase();
      console.log('[App] Firebase initialized');
    } catch (error) {
      console.error('[App] Firebase initialization error:', error);
    }
  }, []);

  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
