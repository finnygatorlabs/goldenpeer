# SeniorShield App - Transfer Guide to Replit

## Overview
This guide walks you through transferring the complete SeniorShield reminder system with Firebase push notifications and family member email notifications to your Replit project.

## Files Included

### Backend Files
- `server/routers.ts` - All tRPC API endpoints (reminders, family members, auth)
- `server/db.ts` - Database query helpers
- `server/reminders-db.ts` - Reminder-specific database functions
- `server/family-members-db.ts` - Family member database functions
- `server/notifications.ts` - Firebase Cloud Messaging service
- `server/email-service.ts` - Email notification service for family members
- `server/reminder-scheduler.ts` - Scheduled job runner (runs every minute)

### Frontend Files
- `client/src/pages/Dashboard.tsx` - Main dashboard with Reminders, Family, Settings tabs
- `client/src/pages/RemindersTab.tsx` - Reminders management UI
- `client/src/pages/FamilyMembersTab.tsx` - Family members management UI
- `client/src/lib/firebase.ts` - Firebase initialization and setup
- `client/src/_core/hooks/usePushNotifications.ts` - Push notification hook
- `client/src/components/NotificationSetup.tsx` - Notification setup component
- `client/public/firebase-messaging-sw.js` - Service worker for background notifications
- `client/src/App.tsx` - Updated App with Firebase initialization

### Database & Config
- `drizzle/schema.ts` - Updated schema with reminders and family_members tables
- `package.json` - Updated dependencies

## Step-by-Step Transfer Instructions

### 1. Copy Backend Files
```bash
# Copy all server files to your Replit project
cp -r server/* your-replit/server/
```

### 2. Copy Frontend Files
```bash
# Copy all client files
cp -r client/src/pages/* your-replit/client/src/pages/
cp -r client/src/lib/firebase.ts your-replit/client/src/lib/
cp -r client/src/_core/hooks/usePushNotifications.ts your-replit/client/src/_core/hooks/
cp -r client/src/components/NotificationSetup.tsx your-replit/client/src/components/
cp -r client/public/firebase-messaging-sw.js your-replit/client/public/
cp client/src/App.tsx your-replit/client/src/
```

### 3. Update Database Schema
```bash
# Copy the updated schema
cp drizzle/schema.ts your-replit/drizzle/

# Run migrations
cd your-replit
pnpm db:push
```

### 4. Update Dependencies
```bash
# Copy package.json and install new dependencies
cp package.json your-replit/
cd your-replit
pnpm install
```

### 5. Set Environment Variables
Add these to your Replit `.env` file:

```env
# Firebase Configuration
FIREBASE_SERVICE_ACCOUNT_KEY=<your Firebase admin SDK JSON key>
VITE_FIREBASE_API_KEY=AIzaSyDorLQotjH6cda5p1q5s5uqAMgLYPYhS6c
VITE_FIREBASE_APP_ID=1:61401220114:web:e370fcbcbf8646c98e44cb
VITE_FIREBASE_MESSAGING_SENDER_ID=61401220114
VITE_FIREBASE_VAPID_KEY=BJvIHu5_myU4BFnclbhaEYOnq4oT6x78r_Sw9o8CaMdElnBqYWPB-a0xNsvycik1694P-p4Z9U9smy4oO4IgqHE

# Database
DATABASE_URL=<your MySQL/TiDB connection string>

# Auth
JWT_SECRET=<your JWT secret>
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=<your OAuth portal URL>
VITE_APP_ID=<your app ID>

# Owner Info
OWNER_NAME=<your name>
OWNER_OPEN_ID=<your open ID>

# Manus APIs
BUILT_IN_FORGE_API_URL=<Manus API URL>
BUILT_IN_FORGE_API_KEY=<Manus API key>
VITE_FRONTEND_FORGE_API_URL=<Manus frontend API URL>
VITE_FRONTEND_FORGE_API_KEY=<Manus frontend API key>
```

### 6. Update App Routes
Make sure your `client/src/App.tsx` includes the Dashboard route:
```tsx
import Dashboard from "@/pages/Dashboard";

// In your router:
<Route path="/dashboard" component={Dashboard} />
```

### 7. Test the Application
```bash
# Start dev server
pnpm dev

# Navigate to http://localhost:3000/dashboard
# You should see the Reminders, Family, and Settings tabs
```

## Features Included

### Reminders System
- Create/edit/delete reminders
- 6 reminder types: Medication, Water, Meal, Appointment, Wellness Check, Custom
- Daily and weekly scheduling
- Firebase push notifications
- Test notification feature
- Device token management

### Family Members System
- Add/edit/delete family members
- Email notification preferences (all, missed only, daily summary, none)
- Welcome email when family member is added
- Automatic email notifications on reminder status changes

### Push Notifications
- Firebase Cloud Messaging integration
- Background notification support via service worker
- Notification setup flow for users
- Device token registration and management

### Scheduled Jobs
- Reminder scheduler runs every minute
- Automatically sends notifications for due reminders
- Tracks reminder history and status

## Database Schema Changes

### New Tables
1. **reminders** - Stores reminder data (type, time, frequency, etc.)
2. **device_tokens** - Stores Firebase device tokens for push notifications
3. **reminder_history** - Tracks reminder delivery and completion status
4. **family_members** - Stores family member contact info and preferences

## Troubleshooting

### Push Notifications Not Working
1. Verify Firebase configuration in `.env`
2. Check that service worker is registered (`firebase-messaging-sw.js`)
3. Ensure user has granted notification permissions
4. Check browser console for errors

### Reminders Not Sending
1. Verify reminder scheduler is running (check logs)
2. Ensure device tokens are registered
3. Check Firebase Cloud Messaging quota
4. Verify reminder time is set correctly

### Email Notifications Not Sending
1. Verify email service configuration
2. Check that family members are added with correct email
3. Verify notification preference is not set to "none"
4. Check email service logs

## Support
If you encounter any issues during transfer, check:
1. All files are in correct directories
2. Environment variables are set correctly
3. Database migrations have run (`pnpm db:push`)
4. Dependencies are installed (`pnpm install`)
5. Dev server is running without errors

## Next Steps
After successful transfer:
1. Test the reminder creation and notification flow
2. Add test family members and verify email notifications
3. Test push notifications on a real device
4. Consider adding SMS escalation for critical reminders
5. Build reminder adherence tracking dashboard
