import { getRemindersToSend, getUserDeviceTokens, recordReminderHistory } from "./reminders-db";
import { sendReminderNotification } from "./notifications";

/**
 * Run the reminder scheduler
 * This should be called every minute to check and send reminders
 */
export async function runReminderScheduler() {
  try {
    console.log("[Scheduler] Running reminder scheduler...");
    
    const remindersToSend = await getRemindersToSend();
    
    if (remindersToSend.length === 0) {
      console.log("[Scheduler] No reminders to send");
      return;
    }

    console.log(`[Scheduler] Found ${remindersToSend.length} reminders to send`);

    for (const { reminder, userId } of remindersToSend) {
      try {
        // Get user's device tokens
        const deviceTokens = await getUserDeviceTokens(userId);
        
        if (deviceTokens.length === 0) {
          console.log(`[Scheduler] No device tokens for user ${userId}, skipping reminder ${reminder.id}`);
          await recordReminderHistory(reminder.id, userId, "missed", "No device tokens registered");
          continue;
        }

        // Send notification to all devices
        for (const token of deviceTokens) {
          try {
            await sendReminderNotification(token, reminder);
            console.log(`[Scheduler] Sent reminder ${reminder.id} to user ${userId}`);
            await recordReminderHistory(reminder.id, userId, "sent");
          } catch (error) {
            console.error(`[Scheduler] Failed to send reminder ${reminder.id} to token ${token}:`, error);
            await recordReminderHistory(reminder.id, userId, "missed", `Failed to send: ${error}`);
          }
        }
      } catch (error) {
        console.error(`[Scheduler] Error processing reminder ${reminder.id}:`, error);
      }
    }

    console.log("[Scheduler] Reminder scheduler completed");
  } catch (error) {
    console.error("[Scheduler] Fatal error in reminder scheduler:", error);
  }
}

/**
 * Start the reminder scheduler
 * Runs every minute
 */
export function startReminderScheduler() {
  console.log("[Scheduler] Starting reminder scheduler...");
  
  // Run immediately on startup
  runReminderScheduler().catch(err => {
    console.error("[Scheduler] Initial run failed:", err);
  });

  // Run every minute
  const intervalId = setInterval(() => {
    runReminderScheduler().catch(err => {
      console.error("[Scheduler] Scheduled run failed:", err);
    });
  }, 60 * 1000); // 60 seconds

  return intervalId;
}

/**
 * Stop the reminder scheduler
 */
export function stopReminderScheduler(intervalId: NodeJS.Timeout) {
  console.log("[Scheduler] Stopping reminder scheduler...");
  clearInterval(intervalId);
}
