import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getMessaging, Message } from "firebase-admin/messaging";
import type { Reminder } from "../drizzle/schema";

let messagingInstance: ReturnType<typeof getMessaging> | null = null;

/**
 * Initialize Firebase Admin SDK for push notifications
 */
function initializeFirebase() {
  if (messagingInstance) {
    return messagingInstance;
  }

  try {
    const serviceAccountKey = process.env.FIREBASE_SERVICE_ACCOUNT_KEY;
    if (!serviceAccountKey) {
      throw new Error("FIREBASE_SERVICE_ACCOUNT_KEY environment variable not set");
    }

    const serviceAccount = JSON.parse(serviceAccountKey);
    
    // Check if Firebase app is already initialized
    if (getApps().length === 0) {
      initializeApp({
        credential: cert(serviceAccount),
      });
    }

    messagingInstance = getMessaging();
    return messagingInstance;
  } catch (error) {
    console.error("[Firebase] Initialization failed:", error);
    throw error;
  }
}

/**
 * Send a push notification to a device
 */
export async function sendPushNotification(
  deviceToken: string,
  title: string,
  body: string,
  data?: Record<string, string>
): Promise<string> {
  try {
    const messaging = initializeFirebase();
    
    const message: Message = {
      token: deviceToken,
      notification: {
        title,
        body,
      },
      data: {
        ...data,
        timestamp: new Date().toISOString(),
      },
      android: {
        priority: "high",
        notification: {
          sound: "default",
          channelId: "reminders",
        },
      },
      apns: {
        payload: {
          aps: {
            alert: {
              title,
              body,
            },
            sound: "default",
            badge: 1,
          },
        },
      },
    };

    const response = await messaging.send(message);
    console.log(`[Firebase] Notification sent successfully. Message ID: ${response}`);
    return response;
  } catch (error) {
    console.error("[Firebase] Failed to send notification:", error);
    throw error;
  }
}

/**
 * Send a reminder notification
 */
export async function sendReminderNotification(
  deviceToken: string,
  reminder: Reminder
): Promise<string> {
  const title = "SeniorShield Reminder";
  const body = reminder.description || reminder.title;
  
  const data: Record<string, string> = {
    reminderId: reminder.id.toString(),
    type: reminder.type,
    action: "reminder",
  };

  return sendPushNotification(deviceToken, title, body, data);
}

/**
 * Send a multicast notification to multiple devices
 */
export async function sendMulticastNotification(
  deviceTokens: string[],
  title: string,
  body: string,
  data?: Record<string, string>
): Promise<{ successCount: number; failureCount: number }> {
  try {
    const messaging = initializeFirebase();
    
    const message: Message = {
      notification: {
        title,
        body,
      },
      data: {
        ...data,
        timestamp: new Date().toISOString(),
      },
      android: {
        priority: "high",
        notification: {
          sound: "default",
          channelId: "reminders",
        },
      },
      apns: {
        payload: {
          aps: {
            alert: {
              title,
              body,
            },
            sound: "default",
            badge: 1,
          },
        },
      },
    };

    const response = await messaging.sendMulticast(
      deviceTokens.map(token => ({ ...message, token }))
    );

    console.log(`[Firebase] Multicast sent. Success: ${response.successCount}, Failures: ${response.failureCount}`);
    
    // Log failures for debugging
    response.responses.forEach((resp, idx) => {
      if (!resp.success) {
        console.warn(`[Firebase] Failed to send to token ${deviceTokens[idx]}: ${resp.error?.message}`);
      }
    });

    return {
      successCount: response.successCount,
      failureCount: response.failureCount,
    };
  } catch (error) {
    console.error("[Firebase] Multicast failed:", error);
    throw error;
  }
}

/**
 * Test Firebase connection
 */
export async function testFirebaseConnection(): Promise<boolean> {
  try {
    initializeFirebase();
    console.log("[Firebase] Connection test passed");
    return true;
  } catch (error) {
    console.error("[Firebase] Connection test failed:", error);
    return false;
  }
}
