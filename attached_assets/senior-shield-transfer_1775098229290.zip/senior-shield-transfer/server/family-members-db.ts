import { getDb } from "./db";
import { familyMembers, InsertFamilyMember, FamilyMember } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";

/**
 * Get all family members for a user
 */
export async function getFamilyMembers(userId: number): Promise<FamilyMember[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(familyMembers)
      .where(and(eq(familyMembers.userId, userId), eq(familyMembers.isActive, true)));
  } catch (error) {
    console.error("[Family Members DB] Error getting family members:", error);
    return [];
  }
}

/**
 * Get a specific family member
 */
export async function getFamilyMember(id: number, userId: number): Promise<FamilyMember | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .select()
      .from(familyMembers)
      .where(and(eq(familyMembers.id, id), eq(familyMembers.userId, userId)))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Family Members DB] Error getting family member:", error);
    return null;
  }
}

/**
 * Add a new family member
 */
export async function addFamilyMember(
  userId: number,
  data: Omit<InsertFamilyMember, "userId">
): Promise<FamilyMember | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .insert(familyMembers)
      .values({
        ...data,
        userId,
      })
      .returning();

    return result[0] || null;
  } catch (error) {
    console.error("[Family Members DB] Error adding family member:", error);
    return null;
  }
}

/**
 * Update a family member
 */
export async function updateFamilyMember(
  id: number,
  userId: number,
  data: Partial<Omit<InsertFamilyMember, "userId">>
): Promise<FamilyMember | null> {
  const db = await getDb();
  if (!db) return null;

  try {
    const result = await db
      .update(familyMembers)
      .set(data)
      .where(and(eq(familyMembers.id, id), eq(familyMembers.userId, userId)))
      .returning();

    return result[0] || null;
  } catch (error) {
    console.error("[Family Members DB] Error updating family member:", error);
    return null;
  }
}

/**
 * Delete a family member (soft delete - mark as inactive)
 */
export async function deleteFamilyMember(id: number, userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;

  try {
    await db
      .update(familyMembers)
      .set({ isActive: false })
      .where(and(eq(familyMembers.id, id), eq(familyMembers.userId, userId)));

    return true;
  } catch (error) {
    console.error("[Family Members DB] Error deleting family member:", error);
    return false;
  }
}

/**
 * Get family members with specific notification preference
 */
export async function getFamilyMembersByNotificationPreference(
  userId: number,
  preference: "all" | "missed_only" | "summary_only" | "none"
): Promise<FamilyMember[]> {
  const db = await getDb();
  if (!db) return [];

  try {
    return await db
      .select()
      .from(familyMembers)
      .where(
        and(
          eq(familyMembers.userId, userId),
          eq(familyMembers.isActive, true),
          eq(familyMembers.notificationPreference, preference)
        )
      );
  } catch (error) {
    console.error("[Family Members DB] Error getting family members by preference:", error);
    return [];
  }
}
