import { eq, and } from "drizzle-orm";
import { reminders, reminderHistory, deviceTokens, type InsertReminder, type Reminder } from "../drizzle/schema";
import { getDb } from "./db";

/**
 * Get all reminders for a user
 */
export async function getUserReminders(userId: number): Promise<Reminder[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(reminders)
    .where(and(eq(reminders.userId, userId), eq(reminders.isActive, true)))
    .orderBy(reminders.time);
}

/**
 * Get a specific reminder
 */
export async function getReminder(reminderId: number, userId: number): Promise<Reminder | undefined> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(reminders)
    .where(and(eq(reminders.id, reminderId), eq(reminders.userId, userId)))
    .limit(1);

  return result[0];
}

/**
 * Create a new reminder
 */
export async function createReminder(userId: number, data: Omit<InsertReminder, "userId">): Promise<Reminder> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(reminders).values({
    userId,
    ...data,
  } as InsertReminder);

  // Fetch and return the created reminder
  const created = await db
    .select()
    .from(reminders)
    .where(eq(reminders.id, Number(result.insertId)))
    .limit(1);

  if (!created[0]) throw new Error("Failed to create reminder");
  return created[0];
}

/**
 * Update a reminder
 */
export async function updateReminder(
  reminderId: number,
  userId: number,
  data: Partial<Omit<InsertReminder, "userId">>
): Promise<Reminder> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Verify ownership
  const existing = await getReminder(reminderId, userId);
  if (!existing) throw new Error("Reminder not found");

  await db
    .update(reminders)
    .set(data)
    .where(and(eq(reminders.id, reminderId), eq(reminders.userId, userId)));

  const updated = await getReminder(reminderId, userId);
  if (!updated) throw new Error("Failed to update reminder");
  return updated;
}

/**
 * Delete a reminder (soft delete)
 */
export async function deleteReminder(reminderId: number, userId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(reminders)
    .set({ isActive: false })
    .where(and(eq(reminders.id, reminderId), eq(reminders.userId, userId)));
}

/**
 * Get all device tokens for a user
 */
export async function getUserDeviceTokens(userId: number): Promise<string[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const tokens = await db
    .select({ token: deviceTokens.token })
    .from(deviceTokens)
    .where(and(eq(deviceTokens.userId, userId), eq(deviceTokens.isActive, true)));

  return tokens.map(t => t.token);
}

/**
 * Register a device token for a user
 */
export async function registerDeviceToken(
  userId: number,
  token: string,
  deviceName?: string,
  platform: "ios" | "android" | "web" = "web"
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Check if token already exists
  const existing = await db
    .select()
    .from(deviceTokens)
    .where(and(eq(deviceTokens.token, token), eq(deviceTokens.userId, userId)))
    .limit(1);

  if (existing[0]) {
    // Update existing token
    await db
      .update(deviceTokens)
      .set({ isActive: true, updatedAt: new Date() })
      .where(eq(deviceTokens.id, existing[0].id));
  } else {
    // Insert new token
    await db.insert(deviceTokens).values({
      userId,
      token,
      deviceName,
      platform,
      isActive: true,
    });
  }
}

/**
 * Unregister a device token
 */
export async function unregisterDeviceToken(userId: number, token: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(deviceTokens)
    .set({ isActive: false })
    .where(and(eq(deviceTokens.token, token), eq(deviceTokens.userId, userId)));
}

/**
 * Get reminders that should be sent now (within the next minute)
 */
export async function getRemindersToSend(): Promise<Array<{ reminder: Reminder; userId: number }>> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const currentDay = now.getDay();

  // Get all active reminders
  const allReminders = await db
    .select()
    .from(reminders)
    .where(eq(reminders.isActive, true));

  // Filter reminders that should be sent now
  const remindersToSend = allReminders.filter(reminder => {
    // Check if time matches (with 1-minute tolerance)
    const [reminderHour, reminderMinute] = reminder.time.split(":").map(Number);
    const reminderTimeInMinutes = reminderHour * 60 + reminderMinute;
    const currentTimeInMinutes = now.getHours() * 60 + now.getMinutes();
    
    if (Math.abs(reminderTimeInMinutes - currentTimeInMinutes) > 1) {
      return false;
    }

    // Check frequency
    if (reminder.frequency === "daily") {
      return true;
    }

    if (reminder.frequency === "weekly") {
      const daysOfWeek = reminder.daysOfWeek?.split(",").map(Number) || [];
      return daysOfWeek.includes(currentDay);
    }

    return false;
  });

  return remindersToSend.map(reminder => ({
    reminder,
    userId: reminder.userId,
  }));
}

/**
 * Record a reminder history entry
 */
export async function recordReminderHistory(
  reminderId: number,
  userId: number,
  status: "sent" | "completed" | "snoozed" | "missed" | "dismissed",
  notes?: string
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(reminderHistory).values({
    reminderId,
    userId,
    status,
    scheduledTime: new Date(),
    sentTime: status === "sent" ? new Date() : undefined,
    completedTime: status === "completed" ? new Date() : undefined,
    notes,
  });
}
