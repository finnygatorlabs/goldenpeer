import { notifyOwner } from "./_core/notification";

/**
 * Email notification templates for family members
 */

interface FamilyMemberNotification {
  familyMemberEmail: string;
  seniorName: string;
  reminderTitle: string;
  reminderType: string;
  status: "completed" | "missed" | "snoozed";
  timestamp: Date;
  message?: string;
}

/**
 * Send email notification to family member about reminder status
 */
export async function sendFamilyMemberEmail(notification: FamilyMemberNotification): Promise<boolean> {
  try {
    const { familyMemberEmail, seniorName, reminderTitle, reminderType, status, timestamp, message } = notification;

    // Format the status message
    let statusMessage = "";
    let subject = "";

    switch (status) {
      case "completed":
        statusMessage = `✓ ${seniorName} completed their ${reminderType} reminder`;
        subject = `Reminder Completed: ${seniorName} - ${reminderTitle}`;
        break;
      case "missed":
        statusMessage = `⚠ ${seniorName} missed their ${reminderType} reminder`;
        subject = `Reminder Missed: ${seniorName} - ${reminderTitle}`;
        break;
      case "snoozed":
        statusMessage = `⏰ ${seniorName} snoozed their ${reminderType} reminder`;
        subject = `Reminder Snoozed: ${seniorName} - ${reminderTitle}`;
        break;
    }

    // Create email content
    const emailContent = `
Dear Family Member,

${statusMessage}

Reminder Details:
- Senior: ${seniorName}
- Reminder: ${reminderTitle}
- Type: ${reminderType}
- Time: ${timestamp.toLocaleString()}
${message ? `- Note: ${message}` : ""}

This is an automated notification from SeniorShield. Family members receive updates about reminder adherence to help ensure seniors stay on track with their daily routines.

Best regards,
SeniorShield Team
    `.trim();

    // Use the built-in notification system to send email
    // In production, this would integrate with an email service like SendGrid, Mailgun, or AWS SES
    const result = await notifyOwner({
      title: subject,
      content: emailContent,
    });

    if (result) {
      console.log(`[Email] Notification sent to ${familyMemberEmail} about ${reminderTitle}`);
    } else {
      console.warn(`[Email] Failed to send notification to ${familyMemberEmail}`);
    }

    return result;
  } catch (error) {
    console.error("[Email] Error sending family member notification:", error);
    return false;
  }
}

/**
 * Send reminder summary email to family members
 */
export async function sendRemindersummaryEmail(
  familyMemberEmail: string,
  seniorName: string,
  remindersData: Array<{
    title: string;
    type: string;
    status: "completed" | "missed" | "snoozed";
    time: string;
  }>
): Promise<boolean> {
  try {
    const completedCount = remindersData.filter(r => r.status === "completed").length;
    const missedCount = remindersData.filter(r => r.status === "missed").length;
    const snoozeCount = remindersData.filter(r => r.status === "snoozed").length;

    const remindersList = remindersData
      .map(r => `- ${r.title} (${r.type}): ${r.status.toUpperCase()}`)
      .join("\n");

    const emailContent = `
Dear Family Member,

Here's today's reminder summary for ${seniorName}:

Summary:
- Completed: ${completedCount}
- Missed: ${missedCount}
- Snoozed: ${snoozeCount}

Today's Reminders:
${remindersList}

Keep supporting your loved one! Regular adherence to reminders helps maintain their health and independence.

Best regards,
SeniorShield Team
    `.trim();

    const result = await notifyOwner({
      title: `Daily Reminder Summary for ${seniorName}`,
      content: emailContent,
    });

    return result;
  } catch (error) {
    console.error("[Email] Error sending reminder summary:", error);
    return false;
  }
}

/**
 * Send welcome email to new family member
 */
export async function sendWelcomeEmail(
  familyMemberEmail: string,
  familyMemberName: string,
  seniorName: string
): Promise<boolean> {
  try {
    const emailContent = `
Dear ${familyMemberName},

Welcome to SeniorShield! You've been added as a family member for ${seniorName}.

You will now receive email notifications about:
- Completed reminders
- Missed reminders
- Snoozed reminders
- Daily reminder summaries

These notifications help you stay informed about ${seniorName}'s daily routine and health adherence.

If you have any questions or need to update your notification preferences, please contact us.

Best regards,
SeniorShield Team
    `.trim();

    const result = await notifyOwner({
      title: `Welcome to SeniorShield - ${seniorName}'s Family Network`,
      content: emailContent,
    });

    return result;
  } catch (error) {
    console.error("[Email] Error sending welcome email:", error);
    return false;
  }
}
