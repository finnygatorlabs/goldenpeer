import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getUserReminders,
  getReminder,
  createReminder,
  updateReminder,
  deleteReminder,
  getUserDeviceTokens,
  registerDeviceToken,
  unregisterDeviceToken,
} from "./reminders-db";
import { sendReminderNotification } from "./notifications";
import {
  getFamilyMembers,
  getFamilyMember,
  addFamilyMember,
  updateFamilyMember,
  deleteFamilyMember,
} from "./family-members-db";
import { sendFamilyMemberEmail, sendWelcomeEmail } from "./email-service";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  reminders: router({
    // Get all reminders for the current user
    list: protectedProcedure.query(async ({ ctx }) => {
      return getUserReminders(ctx.user.id);
    }),

    // Get a specific reminder
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return getReminder(input.id, ctx.user.id);
      }),

    // Create a new reminder
    create: protectedProcedure
      .input(
        z.object({
          type: z.enum(["medication", "water", "meal", "appointment", "wellness", "custom"]),
          title: z.string().min(1).max(255),
          description: z.string().optional(),
          time: z.string().regex(/^\d{2}:\d{2}$/), // HH:MM format
          frequency: z.enum(["daily", "weekly", "custom"]).default("daily"),
          daysOfWeek: z.string().optional(), // "1,3,5" for Mon, Wed, Fri
          dosage: z.string().optional(),
          notificationEnabled: z.boolean().default(true),
          notificationType: z.enum(["push", "sms", "email", "push_sms", "push_email"]).default("push"),
          snoozeMinutes: z.number().default(15),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return createReminder(ctx.user.id, {
          ...input,
          isActive: true,
        });
      }),

    // Update a reminder
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          type: z.enum(["medication", "water", "meal", "appointment", "wellness", "custom"]).optional(),
          title: z.string().min(1).max(255).optional(),
          description: z.string().optional(),
          time: z.string().regex(/^\d{2}:\d{2}$/).optional(),
          frequency: z.enum(["daily", "weekly", "custom"]).optional(),
          daysOfWeek: z.string().optional(),
          dosage: z.string().optional(),
          notificationEnabled: z.boolean().optional(),
          notificationType: z.enum(["push", "sms", "email", "push_sms", "push_email"]).optional(),
          snoozeMinutes: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...data } = input;
        return updateReminder(id, ctx.user.id, data);
      }),

    // Delete a reminder
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteReminder(input.id, ctx.user.id);
        return { success: true };
      }),

    // Register a device token for push notifications
    registerDevice: protectedProcedure
      .input(
        z.object({
          token: z.string(),
          deviceName: z.string().optional(),
          platform: z.enum(["ios", "android", "web"]).default("web"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await registerDeviceToken(ctx.user.id, input.token, input.deviceName, input.platform);
        return { success: true };
      }),

    // Unregister a device token
    unregisterDevice: protectedProcedure
      .input(z.object({ token: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await unregisterDeviceToken(ctx.user.id, input.token);
        return { success: true };
      }),

    // Get all device tokens for the current user
    getDevices: protectedProcedure.query(async ({ ctx }) => {
      return getUserDeviceTokens(ctx.user.id);
    }),

    // Test send a reminder notification
    testNotification: protectedProcedure
      .input(z.object({ reminderId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const reminder = await getReminder(input.reminderId, ctx.user.id);
        if (!reminder) throw new Error("Reminder not found");

        const tokens = await getUserDeviceTokens(ctx.user.id);
        if (tokens.length === 0) throw new Error("No device tokens registered");

        // Send to first device
        await sendReminderNotification(tokens[0], reminder);
        return { success: true, message: "Test notification sent" };
      }),
  }),

  familyMembers: router({
    // Get all family members for the current user
    list: protectedProcedure.query(async ({ ctx }) => {
      return getFamilyMembers(ctx.user.id);
    }),

    // Get a specific family member
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return getFamilyMember(input.id, ctx.user.id);
      }),

    // Add a new family member
    add: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          email: z.string().email(),
          relationship: z.string().optional(),
          notificationPreference: z.enum(["all", "missed_only", "summary_only", "none"]).default("all"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const familyMember = await addFamilyMember(ctx.user.id, input);
        if (familyMember) {
          // Send welcome email
          await sendWelcomeEmail(input.email, input.name, ctx.user.name || "Your loved one");
        }
        return familyMember;
      }),

    // Update a family member
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().min(1).max(255).optional(),
          email: z.string().email().optional(),
          relationship: z.string().optional(),
          notificationPreference: z.enum(["all", "missed_only", "summary_only", "none"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { id, ...updateData } = input;
        return updateFamilyMember(id, ctx.user.id, updateData);
      }),

    // Delete a family member
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        return deleteFamilyMember(input.id, ctx.user.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
