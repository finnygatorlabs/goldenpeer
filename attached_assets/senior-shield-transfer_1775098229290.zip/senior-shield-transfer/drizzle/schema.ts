import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Device tokens for push notifications
 * Each user can have multiple devices (phone, tablet, etc.)
 */
export const deviceTokens = mysqlTable("device_tokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  token: text("token").notNull(), // Firebase Cloud Messaging token
  deviceName: varchar("deviceName", { length: 255 }), // e.g., "iPhone 14", "Samsung Galaxy"
  platform: mysqlEnum("platform", ["ios", "android", "web"]).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DeviceToken = typeof deviceTokens.$inferSelect;
export type InsertDeviceToken = typeof deviceTokens.$inferInsert;

/**
 * Reminders for users
 * Supports medication, water, meals, appointments, wellness checks, and custom reminders
 */
export const reminders = mysqlTable("reminders", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  // Reminder details
  type: mysqlEnum("type", ["medication", "water", "meal", "appointment", "wellness", "custom"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(), // e.g., "Take blood pressure medication"
  description: text("description"), // e.g., "Take with food and water"
  
  // Scheduling
  time: varchar("time", { length: 5 }).notNull(), // HH:MM format (24-hour)
  frequency: mysqlEnum("frequency", ["daily", "weekly", "custom"]).default("daily").notNull(),
  daysOfWeek: varchar("daysOfWeek", { length: 50 }), // "1,3,5" for Mon, Wed, Fri (0=Sunday, 6=Saturday)
  
  // Medication-specific fields
  dosage: varchar("dosage", { length: 255 }), // e.g., "2 tablets", "5ml"
  
  // Notification preferences
  notificationEnabled: boolean("notificationEnabled").default(true).notNull(),
  notificationType: mysqlEnum("notificationType", ["push", "sms", "email", "push_sms", "push_email"]).default("push").notNull(),
  
  // Snooze options
  snoozeMinutes: int("snoozeMinutes").default(15), // Default snooze duration
  
  // Status
  isActive: boolean("isActive").default(true).notNull(),
  
  // Timestamps
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Reminder = typeof reminders.$inferSelect;
export type InsertReminder = typeof reminders.$inferInsert;

/**
 * Reminder history - tracks when reminders were sent and completed
 */
export const reminderHistory = mysqlTable("reminder_history", {
  id: int("id").autoincrement().primaryKey(),
  reminderId: int("reminderId").notNull(),
  userId: int("userId").notNull(),
  
  // Status
  status: mysqlEnum("status", ["sent", "completed", "snoozed", "missed", "dismissed"]).notNull(),
  
  // Timing
  scheduledTime: timestamp("scheduledTime").notNull(), // When it was supposed to be sent
  sentTime: timestamp("sentTime"), // When it was actually sent
  completedTime: timestamp("completedTime"), // When user marked as completed
  
  // Additional data
  snoozedUntil: timestamp("snoozedUntil"), // If snoozed, when to send again
  notes: text("notes"), // User notes, e.g., "Took medication with breakfast"
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReminderHistory = typeof reminderHistory.$inferSelect;
export type InsertReminderHistory = typeof reminderHistory.$inferInsert;

/**
 * Family members - tracks family members who receive email notifications
 * Each senior can have multiple family members (spouse, children, etc.)
 */
export const familyMembers = mysqlTable("family_members", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // The senior's user ID
  name: varchar("name", { length: 255 }).notNull(), // Family member's name
  email: varchar("email", { length: 320 }).notNull(), // Family member's email
  relationship: varchar("relationship", { length: 100 }), // e.g., "Spouse", "Son", "Daughter", "Caregiver"
  notificationPreference: mysqlEnum("notificationPreference", ["all", "missed_only", "summary_only", "none"]).default("all").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FamilyMember = typeof familyMembers.$inferSelect;
export type InsertFamilyMember = typeof familyMembers.$inferInsert;
